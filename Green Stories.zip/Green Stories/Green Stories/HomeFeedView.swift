//////
//////  HomeFeedView.swift
//////  Green Stories
//////
//////  Created by Aarya Raut on 10/4/24.
//////
////
////import SwiftUI
////
////
////
////struct HomeFeedView: View {
////    
////    @State var posts = [
////        Post(userId: "username", id: "dfowihef", image: "iceCaps", title: "Climate Change", caption: "ergegeg", date: "10/3/24"),
////        Post(userId: "username", id: "dfowihef", image: "iceCaps", title: "Climate Change", caption: "ergegeg", date: "10/3/24"),
////        Post(userId: "username", id: "dfowihef", image: "iceCaps", title: "Climate Change", caption: "ergegeg", date: "10/3/24")]
////    
//    let generator = UINotificationFeedbackGenerator()
//    @State private var toggle : Bool = false
//    @State private var showAlert : Bool = false
////    
////    var body: some View {
////        ZStack() {
////            
////            List($posts) { post in
//                VStack(alignment: .leading) {
//                    
//                    Image(post.image)
//                        .resizable()
//                        .frame(width: 320)
//                        .clipShape(RoundedRectangle(cornerRadius: 10))
//                    HStack(alignment: .top) {
//                        Text(post.title)
//                            .fontDesign(.serif)
//                            .font(.title)
//                            .fontWeight(.bold)
//                        Spacer()
//                        Image(systemName: toggle ? "heart.fill" : "heart")
//                        
//                            .foregroundColor(Color("Custom Color"))
//                            .onTapGesture {
//                                generator.notificationOccurred(.warning)
//                                withAnimation() {
//                                    toggle.toggle()
//                                    if toggle {
//                                        showAlert = true
//                                    }
//                                }
//                            }
//                            .alert("Post Liked", isPresented: $showAlert) {
//                                Button("OK", role: .cancel) {}
//                            }
//                        
//                        HStack(alignment: .top) {
//                            VStack (alignment: .trailing) {
//                                Text("\(post.username)")
//                                    .foregroundStyle(.black)
//                                    .fontDesign(.monospaced)
//                                    .bold()
//                                    .font(.subheadline)
//                                
//                                Text("\(post.date)")
//                                    .foregroundStyle(.black)
//                                    .fontDesign(.monospaced)
//                                    .bold()
//                                    .font(.subheadline)
//                                
//                                Text("\(post.views) views")
//                                    .foregroundStyle(.black)
//                                    .bold()
//                                    .fontDesign(.monospaced)
//                                    .font(.subheadline)
//                            }
//                            
//                            
//                            
//                        }
//                    }
//                    HStack (alignment: .top) {
//                        Text("\(post.caption)")
//                            .font(.caption)
//                            .foregroundStyle(Color("custom gray"))
//                    }
////                    
////                    
////                    
////                    //                HStack(alignment: .top){
////                    //                    Text("\(hike.address)")
////                    //                        .fontDesign(.serif)
////                    //                    Spacer()
////                    //                    Text("\(hike.timing)")
////                    //                        .fontDesign(.monospaced)
////                    //                        .bold()
////                    //                        .foregroundStyle(.cyan)
////                    //                }
////                }
////                .listRowSeparator(.hidden)
////                    .frame(minHeight: 150)
////                    .padding(.all)
////                    .overlay (
////                        RoundedRectangle(cornerRadius: 20)
////                            .fill(.black)
////                            .opacity(0.15)
////                            .shadow(radius: 10)
////                    )
////                
////            }
////            .listStyle(.plain)
////            
////        }
////    }
////    
////}
////    struct HomeFeedView_Previews: PreviewProvider {
////        static var previews: some View {
////            HomeFeedView()
////        }
////    }
////
////
