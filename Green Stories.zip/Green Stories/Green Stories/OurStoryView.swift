//
//  OurStoryView.swift
//  Green Stories
//
//  Created by Aarya Raut on 10/4/24.
//

import SwiftUI

struct OurStoryView: View {
  var body: some View {
      ScrollView {
          VStack {
              Text("I'm sure you know that CO2 emissions are a global problem, but you are mistaken if you think they are caused globally. I know this is not the most pressing concern in your life, and you might feel that you don't have much power over this. But I guarantee you that this will affect all of us and that we have more power than you think. As seen on the maps in image 1 (depicted below), most CO2 emissions come from China, India, Europe, and the U.S. It is purely obscure how less than half of the world emits the most CO2. In spite of this, if we work together, we can reduce CO2 emissions to a level in which our children will play happily outside. The potential for change is within our grasp; we must put in our hope and effort to accomplish it.")
                    
              Image(.image1)
                  .resizable()
                  .aspectRatio(contentMode: .fit)
              Text("(Image 1 - source: GHG Center - Global CO emission data. https://earth.gov/ghgcenter )")
                  .font(.caption)
              
              Text("I have never been to Europe, but my family comes from there. In the past, people throughout Europe would pollute the air without a second thought. Even though this problem has gotten better today, many of us are still clinging to those ideals of the past. My parents and grandparents watched the air turn grey,  and I want the children of Europe to see it be clear again. There were 238,000 premature deaths in 2020, and at this rate, those kids of the future will have to gasp when they take a breath of fresh air. As Europe is a beautiful place, we must ensure it stays lovely.\n\nIn March 2023, Canada went through a series of abundant wildfires. I know that Canada doesn't have the CO2 emission problem I mentioned, but the smoke that those wildfires produced spread throughout the U.S. Thankfully, I was more south, so it didn't affect me much, but I remember how badly it hit the northern states. It was horrific, as smoke covered the cities, and it became more challenging for them to breathe. As tricky enough for an individual with total health, those with health conditions were in a horrible situation. As breathing was already difficult enough, those with asthma, respiratory, and heart issues struggled through that time. This event was only one isolated issue with dramatic effects. With the CO2 we consistently emit, we don't see the immediate effects like we did with the wildfires; the effects accumulate over time. Tomorrow may seem the same, but it gets a little worse every day, and eventually, we will see that breathing is more challenging. We are just secretly poisoning ourselves. It is our duty to ensure that we get rid of this poison and make the air more breathable for us and those who need it more.\n\nWhen going to India I have seen significant air pollution, which in fact was so bad that upon arriving at the airport you couldn't see 100 feet out of the windows at the planes even one gate on either side. The pollution is also dangerous and I have heard several stories of people getting into road accidents due to not being able to see in front of them due to the smog. The smog is grey smog, the most dangerous type due to the sulphurous elements it contains. A minor inconvenience I have experienced is the pollution has caused drivers to have to go slower on major roads that are exiting the city, slowing down the packed traffic even more which then further contributes to pollution. Waste management and industrial emissions are two factors that contribute to the smog, as companies aren't well regulated as well as personal waste management.\n\nI have never been to China, but I have many close friends who have. I know that the air pollution there gets terrible, especially near Shanghai, and I know it must be difficult for them to travel there with that air pollution. I've seen pictures of people there wearing masks before the pandemic, not to protect themselves from disease but from the air. This kind of problem doesn't go away overnight, and the people of Shanghai will never fully recover from this pollution's damage to their health. But this is something we all can do better. Things must be fixed so that people living in Shanghai and other places worldwide can live complete and healthy lives.\n\nThe significant CO2 emissions for China and India are due to their high population (over one billion people each). As seen in image two, Europe and the U.S. have a much smaller population yet emit relatively as much CO2 as them. This is undeniably true, yet completely unacceptable. China emits eight metric tons of CO2 per capita, India 2 tons, Europe 7.5  tons, and the U.S. 14.9 tons. This means that we are being highly wasteful in the U.S. and Europe. This is awful, significantly, since air pollution increases heart and respiratory diseases, affects young children before and after birth, and causes many premature deaths. You don't want to be responsible for the deaths of those in the future, those who haven't lived their lives yet. But just because China and India have a higher population does not give them a get-out-of-jail-free card. There are ways they can improve their situation in terms of environmental protection and ways we should all try to improve.")
              
              Image(.image2)
                  .resizable()
                  .aspectRatio(contentMode: .fit)
              Text("(image 2 - Source GHG Center - Map of Global CO2 emission and Population density. https://earth.gov/ghgcenter)")
                  .font(.caption)
              
              
              Text("One of the largest, if not largest, use of fossil fuels is to generate electrical power. One obvious improvement for these countries is using renewable energy. Using solar, hydro, or wind energy will reduce the amount of CO2 emission to a great extent. This is also true for the use of nuclear energy. Nuclear energy plants actually have a really small carbon footprint. The only thing with the concept of renewable and nuclear energy is that people think they are the only way to reduce CO2 emissions. Alternative fuel sources like biofuels and hydrogen can emit less CO2 than fossil fuels. Also, improving technology would be beneficial. New tech can allow less fossil fuels to be utilised more efficiently than before. Having us use less fossil fuels than before for our industrial needs. These methods will help lower CO2 emissions, but not everyone will want to put forth the effort. In addition to supporting our countries in taking these actions, we must support them in implementing carbon pricing. Carbon pricing is a method in which countries and companies charge additional fees to other countries, companies, and individuals who use fossil fuels. This encourages them to use other sources of energy for financial use. Even though all of this improves environmental health, this is all taken on a national level, while you can still help on a more individual level. By reducing your energy consumption or adopting solar panel use in your homes, you can directly reduce the amount of carbon dioxide used to generate electricity. Another way to reduce your CO2 emission is by reducing the amount of transportation you use.  Up there with electrical generation, transportation is one of the biggest causes of CO2 emissions. You can reduce your carbon footprint by walking, riding your bike, taking the bus, or using electric cars.\n\nI really hope that in the future, our skies will be clear, our water will be clean, and our children will play without being worried about the poison we put in our world. But right now, that future is getting harder and harder to see if it will become true. And it is up to us to rectify the damages that we have caused—not just for us but for the sake of our children and our future. The time to act is now.")
              
              Image(.pie1)
                  .resizable()
                  .scaledToFit()
              Image(.pie2)
                  .resizable()
                  .scaledToFit()
              Image(.pie3)
                  .resizable()
                  .scaledToFit()
              Image(.pie4)
                  .resizable()
                  .scaledToFit()
              
              Text("Jozwiak, Marcin. “ODIAC Fossil Fuel CO₂ Emissions ... — U.S. Greenhouse Gas Center.” Earth.gov, https://earth.gov/ghgcenter/data-catalog/odiac-ffco2-monthgrid-v2023. Accessed 6 October 2024.\n\n“SEDAC Gridded World Population D... — U.S. Greenhouse Gas Center.” Earth.gov, https://earth.gov/ghgcenter/data-catalog/sedac-popdensity-yeargrid5yr-v4.11. Accessed 6 October 2024.\n\n“SEDAC Gridded World Population D... — U.S. Greenhouse Gas Center.” Earth.gov, https://earth.gov/ghgcenter/data-catalog/sedac-popdensity-yeargrid5yr-v4.11. Accessed 6 October 2024.\n\n“Sources of Greenhouse Gas Emissions | US EPA.” Environmental Protection Agency (EPA), 8 July 2024, https://www.epa.gov/ghgemissions/sources-greenhouse-gas-emissions. Accessed 6 October 2024.\n\n“Sources of Greenhouse Gas Emissions | US EPA.” Environmental Protection Agency (EPA), 8 July 2024, https://www.epa.gov/ghgemissions/sources-greenhouse-gas-emissions. Accessed 6 October 2024.\n\n“Sources of Greenhouse Gas Emissions | US EPA.” Environmental Protection Agency (EPA), 8 July 2024, https://www.epa.gov/ghgemissions/sources-greenhouse-gas-emissions. Accessed 6 October 2024.\n\nTiseo, Ian. “EU-27: per capita GHG emissions 1990-2022.” Statista, 22 May 2024, https://www.statista.com/statistics/986460/co2-emissions-per-cap-eu/. Accessed 6 October 2024.\n\n“Ηow air pollution affects our health | European Environment Agency's home page.” European Environment Agency, 18 October 2023, https://www.eea.europa.eu/en/topics/in-depth/air-pollution/eow-it-affects-our-health. Accessed 6 October 2024.\n\n“India - Countries & Regions - IEA.” India - Countries & Regions - IEA, https://www.iea.org/countries/india/emissions. Accessed 6 October 2024.\n\nKatzman, Mark. “Pollution-related deaths numbered 1.67M in 2019, according to a new report led by Boston College researchers.” Boston College, https://www.bc.edu/bc-web/bcnews/nation-world-society/international/air-pollution-in-inda.html. Accessed 6 October 2024.\n\n“China - Countries & Regions - IEA.” China - Countries & Regions - IEA, https://www.iea.org/countries/china/emissions. Accessed 6 October 2024.\n\nShi, Xiaoming. “Acute Effects of Air Pollution on Human Health in China: Evidence and Prospects.” China CDC Weekly, 5 November 2021, https://weekly.chinacdc.cn/en/article/doi/10.46234/ccdcw2021.229. Accessed 6 October 2024.")
                  .font(.caption2)
              
          }
          .padding()
      }
    
  }
}

struct OurStoryView_Previews: PreviewProvider {
  static var previews: some View {
    OurStoryView()
  }
}
