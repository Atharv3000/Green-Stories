import SwiftUI

struct LogInView: View {
    var body: some View {
        
        @State var email: String = ""
        @State var password: String = ""
        @State var invalidUser = false
        @State var isUserLogin: Bool = false
        @State var inProgress = false
        @State var showAlert: Bool = false
        
        NavigationStack {
            TextField("Name",
                      text: $email,
                      prompt: Text("Enter Email Address")
                                .foregroundColor(Color("Custom Green"))
                                
            )
            .padding()
            .overlay {
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color("Custom Green"), lineWidth: 2)
            }
            .padding(.horizontal)
            
            
            //              Button(action: {
            //                  print("Log In Pressed")
            //              }, label: {
            //                  NavigationLink(destination: TestTabView().navigationBarBackButtonHidden(true)) {
            //                      Text("Log In")
            //                          .frame(maxWidth: .infinity)
            //                          .foregroundColor(.white)
            //                  }
            //              })
            //              .padding()
            //              .buttonStyle(.borderedProminent)
            //              .controlSize(.large)
            
            //                Button {
            //                    Task {
            //
            //                    }
            //                } label : {
            //                    Text("Login")
            //                        .frame(maxWidth: .infinity)
            //                        .foregroundColor(.white)
            //                }
            //                .padding()
            //                .buttonStyle(.borderedProminent)
            //                .controlSize(.large)
            
            
            
            
            //    ZStack() {
            //      Group {
            //        Text("Green Stories")
            //          .font(Font.custom("Inter", size: 24).weight(.heavy))
            //          .foregroundColor(.white)
            //          .offset(x: 4.50, y: -385.50)
            //        Text("Log in")
            //          .font(Font.custom("Inter", size: 48).weight(.heavy))
            //          .foregroundColor(.white)
            //          .offset(x: -0.50, y: -308)
            //        Text("Welcome Back")
            //          .font(Font.custom("Inter", size: 48))
            //          .foregroundColor(Color(red: 0.78, green: 0.78, blue: 0.78))
            //          .offset(x: -0.50, y: -165)
            //        Text("Don't have an account? Sign Up")
            //          .font(Font.custom("Inter", size: 20).weight(.bold))
            //          .foregroundColor(.white)
            //          .offset(x: 1, y: -267)
            //        Rectangle()
            //          .foregroundColor(.clear)
            //          .frame(width: 32, height: 28)
            //          .background(
            //            AsyncImage(url: URL(string: "https://via.placeholder.com/32x28"))
            //          )
            //          .offset(x: -99, y: -386)
            //        TextField("Username", text: $username)
            //          .font(Font.custom("Roboto Mono", size: 16))
            //          .foregroundColor(.white)
            //          .offset(x: -126.50, y: -84.50)
            //        Text("Forgot password?")
            //          .font(Font.custom("Roboto Mono", size: 12))
            //          .foregroundColor(Color(red: 0.55, green: 1, blue: 0.96))
            //          .offset(x: 3.50, y: 215)
            //        Rectangle()
            //          .foregroundColor(.clear)
            //          .frame(width: 331, height: 40)
            //          .background(.white)
            //          .cornerRadius(7)
            //          .overlay(
            //            RoundedRectangle(cornerRadius: 7)
            //              .inset(by: 1.50)
            //              .stroke(Color(red: 0.85, green: 0.85, blue: 0.85), lineWidth: 1.50)
            //          )
            //          .offset(x: 0.50, y: -54)
            //        Text("Password")
            //          .font(Font.custom("Roboto Mono", size: 16))
            //          .foregroundColor(.white)
            //          .offset(x: -126.50, y: -19.50)
            //        Rectangle()
            //          .foregroundColor(.clear)
            //          .frame(width: 331, height: 40)
            //          .background(.white)
            //          .cornerRadius(7)
            //          .overlay(
            //            RoundedRectangle(cornerRadius: 7)
            //              .inset(by: 1.50)
            //              .stroke(Color(red: 0.85, green: 0.85, blue: 0.85), lineWidth: 1.50)
            //          )
            //          .offset(x: 0.50, y: 11)
            //      }
            //        Group {
            //        Rectangle()
            //          .foregroundColor(.clear)
            //          .frame(width: 120, height: 46)
            //          .background(Color(red: 0.12, green: 0.35, blue: 0.38))
            //          .cornerRadius(54)
            //          .overlay(
            //            RoundedRectangle(cornerRadius: 54)
            //              .inset(by: 1)
            //              .stroke(Color(red: 0.78, green: 0.78, blue: 0.78), lineWidth: 1)
            //          )
            //          .offset(x: 0, y: 266)
            //        Text("Log in")
            //          .font(Font.custom("Roboto Mono", size: 16))
            //          .foregroundColor(Color(red: 0.85, green: 0.85, blue: 0.85))
            //          .offset(x: 1, y: 266.50)
            //        Text("Username")
            //          .font(Font.custom("Roboto Mono", size: 16))
            //          .foregroundColor(Color(red: 0.78, green: 0.78, blue: 0.78))
            //          .offset(x: -114.50, y: -53.50)
            //        Text("########")
            //          .font(Font.custom("Roboto Mono", size: 16))
            //          .foregroundColor(Color(red: 0.78, green: 0.78, blue: 0.78))
            //          .offset(x: -114.50, y: 11.50)
            //      }
            //    }
            //    .frame(width: 430, height: 932)
            //    .background(.white);
        }
    }
    
    struct LogInView_Previews: PreviewProvider {
        static var previews: some View {
            LogInView()
        }
    }
}
