//
//  LogInViewTwo.swift
//  Green Stories
//
//  Created by Aarya Raut on 10/6/24.
//

import SwiftUI

struct LogInViewTwo: View {

    @State private var invalidUser = false
//    @State private var isUserLogin: Bool = false
    @State var inProgress = false
    @State var showAlert: Bool = false
    @StateObject var loginviewModel = LoginViewModel()
    
    var body: some View {
        NavigationStack {
            VStack() {
                Text("Log in Page")
                    .font(.title)
                    .bold()
                    .foregroundColor(Color("Start page gradient second"))
                Spacer()
                
                Image(systemName: "green logo")
                    .resizable()
                    .frame(width: 125, height: 200)
                    .aspectRatio(contentMode: .fit)
                    .padding()
                Spacer()
                
                
                TextField("Name",
                          text: $loginviewModel.emailId,
                          prompt: Text("Enter Email Address")
                                    .foregroundColor(Color("Start page gradient second"))
                                    
                )
                .padding()
                .overlay {
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color("Start page gradient second"), lineWidth: 2)
                }
                .padding(.horizontal)
                
                SecureField ("Password",
                             text: $loginviewModel.password,
                             prompt: Text("Enter Password")
                                        .foregroundColor(Color("Start page gradient second"))
                )
                .padding(15)
                .overlay {
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color("Start page gradient second"), lineWidth: 2)
                }
                .padding(.horizontal)
                
                Spacer()
                
                Button(action: {
                    
                    Task {
                        await loginviewModel.login()
                        
                    }
                }, label: {

                        Text("Log In")
                            .frame(maxWidth: .infinity)
                            .foregroundColor(.white)

                })
                .navigationDestination(isPresented: $loginviewModel.isUserLogedIn, destination: {
                    MainTabView()
                        .navigationBarBackButtonHidden(true)
                })
                .padding()
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
    //                Button {
    //                    Task {
    //
    //                    }
    //                } label : {
    //                    Text("Login")
    //                        .frame(maxWidth: .infinity)
    //                        .foregroundColor(.white)
    //                }
    //                .padding()
    //                .buttonStyle(.borderedProminent)
    //                .controlSize(.large)
                
            }.disabled(inProgress)
        }
        
        
        
    }
}

#Preview {
    LogInViewTwo()
}
