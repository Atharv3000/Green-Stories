//
//  TabView.swift
//  Green Stories
//
//  Created by Aarya Raut on 10/6/24.
//

import SwiftUI

struct MainTabView: View {
    var body: some View {
        TabView() {
            NewHomeFeedView()
                .tabItem {
                    Image(systemName: "house")
                    Text("Home Feed")
                }
            OurStoryView()
                .tabItem {
                    Image(systemName: "scroll.fill")
                    Text("Our Story")
                }
            ProfileView()
                .tabItem {
                    Image(systemName: "person")
                    Text("Account")
                }
        }
    }
}

#Preview {
    MainTabView()
}
