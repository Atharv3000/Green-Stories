//
//  Green_StoriesApp.swift
//  Green Stories
//
//  Created by Aarya Raut on 9/30/24.
//

import SwiftUI

@main
struct Green_StoriesApp: App {
    var body: some Scene {
        WindowGroup {
            StartPageView()
        }
    }
}
