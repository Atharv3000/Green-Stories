//
//  ContentView.swift
//  Green Stories
//
//  Created by Aarya Raut on 9/30/24.
//

import SwiftUI


struct StartPageView: View {
    
    @State var isUserLogedIn = false;
    
  var body: some View {
      NavigationStack {
          ZStack() {
              GradientView()
              
              
            Text("Green Stories")
      //            .font(Font.custom("Inter", size: 24).weight(.bold))
                  .fontWeight(.bold)
                  .font(.system(size: 26))
                  .foregroundColor(Color("Start page gradient second"))
              .offset(x: 19.50, y: -369.50)
              
              Image(.whiteLogo)
                  .resizable()
                  .frame(width: 30, height: 30)
                  .offset(x: -85, y: -370)
              
            Text("Stories told")
      //        .font(Font.custom("Inter", size: 40).weight(.heavy))
                  .font(.system(size: 40))
                  .fontWeight(.bold)
              .lineSpacing(60)
              .foregroundColor(.white)
              .offset(x: -9.50, y: -197)
            Text("Make a Change Today")
      //        .font(Font.custom("Roboto Mono", size: 17))
                  .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
              .lineSpacing(25.50)
              .foregroundColor(Color(red: 0.85, green: 0.85, blue: 0.85))
              .offset(x: 0, y: 8)
            Text("No account?")
              .font(Font.custom("Roboto Mono", size: 18))
              .lineSpacing(27)
              .foregroundColor(Color(red: 0.85, green: 0.85, blue: 0.85))
              .offset(x: -58.50, y: 259.50)

              
                 
//                      Text("Log in")
//                      .font(Font.custom("Inter", size: 26).weight(.heavy))
//                      .lineSpacing(39)
//                      .foregroundColor(Color(red: 0.55, green: 1, blue: 0.96))
//                      .offset(x: 0, y: 84.50)
              NavigationLink("Log in", destination: LogInViewTwo())
                  .font(Font.custom("Inter", size: 26).weight(.heavy))
                  .lineSpacing(39)
                  .foregroundColor(Color(red: 0.55, green: 1, blue: 0.96))
                  .offset(x: 0, y: 84.50)
                  

                  
              
              
            Text("Start now")
              .font(Font.custom("Roboto Mono", size: 18))
              .lineSpacing(27)
              .foregroundColor(Color(red: 0.55, green: 1, blue: 0.96))
              .offset(x: 59, y: 259.50)
          }
          .frame(width: 430, height: 932)
          .background(.white)
      }
    
  }
}

struct StartPageView_Previews: PreviewProvider {
  static var previews: some View {
    StartPageView()
  }
}

struct GradientView: View {
    var body: some View {
        LinearGradient(gradient: Gradient(colors: [Color("Start page gradient first"), Color("Start page gradient second")]), startPoint: .topLeading, endPoint: .bottomTrailing)
            .edgesIgnoringSafeArea(.all)
    }
}
