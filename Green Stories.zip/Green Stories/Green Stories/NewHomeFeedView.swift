//
//  NewHomeFeedView.swift
//  Green Stories
//
//  Created by Aarya Raut on 10/6/24.
//

import SwiftUI

struct NewHomeFeedView: View {
    
    @StateObject var postVM = PostViewModel()
    
    let generator = UINotificationFeedbackGenerator()
    @State private var toggle : Bool = false
    @State private var showAlert : Bool = false
    
    var body: some View {
        
        NavigationView {
            List () {
                ForEach(postVM.post) { postItem in
                    VStack (alignment: .leading) {
                        Image(postItem.image)
                            .resizable()
                            .frame(width: 320, height: 150)
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                        
                        HStack (alignment: .top) {
                            Text(postItem.title)
                                .fontDesign(.serif)
                                .font(.title)
                                .fontWeight(.bold)
                            
                            Spacer()
                            
                            HStack(alignment: .top) {
                                VStack (alignment: .trailing) {
                                    Text("\(postItem.userId)")
                                        .foregroundStyle(.black)
                                        .fontDesign(.monospaced)
                                        .bold()
                                        .font(.subheadline)
                                    
                                    Text("\(postItem.date)")
                                        .foregroundStyle(.black)
                                        .fontDesign(.monospaced)
                                        .bold()
                                        .font(.subheadline)
                                    
                                }
                            }
                            
                            
                        }
                        HStack (alignment: .top) {
                            Text("\(postItem.caption)")
                                .font(.caption)
                                .foregroundStyle(Color("custom gray"))
                        }
                    }
                }
                

    //
    //                        HStack(alignment: .top) {
    //
    //
    //
    //
    //                        }
    //                    }
    //                    HStack (alignment: .top) {
    //                        Text("\(postItem.caption)")
    //                            .font(.caption)
    //                            .foregroundStyle(Color("custom gray"))
    //                    }
    //
    //
    //                }
    //            }
            }
            .navigationTitle("Home Feed")
            .onAppear {
                Task {
                    await postVM.loadPostList(userId: "nandha@gmail.com")
                }
            }
            .toolbar {
                Button {
                    postVM.isShowingCreate = true
                } label: {
                    Image(systemName: "plus")
                }
                
            }
            .sheet(isPresented: $postVM.isShowingCreate) {
                CreatePostView(isShowCreate: $postVM.isShowingCreate)
            }
        }
        
    }
}

#Preview {
    NewHomeFeedView()
}

struct CreatePostView: View {
    
//    @State private var title: String = ""
//    @State private var caption: String = ""
//    @State private var story: String = ""
    @Binding var isShowCreate: Bool
    @StateObject var postVM = PostViewModel()

    var body: some View {
        Form {
            
                
            TextField("Title", text: $postVM.title)
            TextField("caption", text: $postVM.caption)
            TextField("Actual Story", text: $postVM.story)
                        .lineLimit(4)
                        .multilineTextAlignment(.leading)
                        .frame(minWidth: 100, maxWidth: 200, minHeight: 100, maxHeight: .infinity, alignment: .topLeading)
                    
                    
            
                    
                    
                
                
            }
        
        Button{
            isShowCreate = false
        } label: {
            Text("Post")
                .font(.title2)
                .fontWeight(.semibold)
                .frame(width: 280, height: 50)
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
        }
        
        Button{
            isShowCreate = false
        } label: {
            Text("Cancel")
                .font(.title2)
                .fontWeight(.semibold)
                .frame(width: 280, height: 50)
                .background(Color.red)
                .foregroundColor(.white)
                .cornerRadius(10)
        }
            
        }
    }

