//
//  ForgetPasswordView.swift
//  Green Stories
//
//  Created by Aarya Raut on 10/4/24.
//

import SwiftUI

struct ForgetPasswordView: View {
  var body: some View {
    ZStack() {
      Group {
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 430, height: 932)
          .background(
            AsyncImage(url: URL(string: "https://via.placeholder.com/430x932"))
          )
          .offset(x: 0, y: 0)
        Text("Green Stories")
          .font(Font.custom("Inter", size: 24).weight(.heavy))
          .foregroundColor(.white)
          .offset(x: 5.50, y: -385.50)
        Text("Forgot Password")
          .font(Font.custom("Inter", size: 48).weight(.heavy))
          .foregroundColor(.white)
          .offset(x: -0.50, y: -308)
        Text("Back to Log in")
          .font(Font.custom("Inter", size: 20).weight(.bold))
          .foregroundColor(.white)
          .offset(x: 5.50, y: -267)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 32, height: 28)
          .background(
            AsyncImage(url: URL(string: "https://via.placeholder.com/32x28"))
          )
          .offset(x: -98, y: -386)
        Text("Email Address")
          .font(Font.custom("Roboto Mono", size: 16))
          .foregroundColor(.white)
          .offset(x: -102.50, y: -174.50)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 331, height: 40)
          .background(.white)
          .cornerRadius(7)
          .overlay(
            RoundedRectangle(cornerRadius: 7)
              .inset(by: 1.50)
              .stroke(Color(red: 0.85, green: 0.85, blue: 0.85), lineWidth: 1.50)
          )
          .offset(x: 0.50, y: -144)
        Text("Phone Number")
          .font(Font.custom("Roboto Mono", size: 16))
          .foregroundColor(.white)
          .offset(x: -108, y: 80.50)
        Text("or")
          .font(Font.custom("Roboto Mono", size: 16))
          .foregroundColor(Color(red: 0.78, green: 0.78, blue: 0.78))
          .offset(x: 1, y: 10.50)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 331, height: 40)
          .background(.white)
          .cornerRadius(7)
          .overlay(
            RoundedRectangle(cornerRadius: 7)
              .inset(by: 1.50)
              .stroke(Color(red: 0.85, green: 0.85, blue: 0.85), lineWidth: 1.50)
          )
          .offset(x: -0.50, y: 111)
      }
        Group {
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 120, height: 46)
          .background(Color(red: 0.12, green: 0.35, blue: 0.38))
          .cornerRadius(54)
          .overlay(
            RoundedRectangle(cornerRadius: 54)
              .inset(by: 1)
              .stroke(Color(red: 0.78, green: 0.78, blue: 0.78), lineWidth: 1)
          )
          .offset(x: 0, y: -67)
        Text("Recover")
          .font(Font.custom("Roboto Mono", size: 16))
          .foregroundColor(Color(red: 0.85, green: 0.85, blue: 0.85))
          .offset(x: 0, y: -66.50)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 120, height: 46)
          .background(Color(red: 0.12, green: 0.35, blue: 0.38))
          .cornerRadius(54)
          .overlay(
            RoundedRectangle(cornerRadius: 54)
              .inset(by: 1)
              .stroke(Color(red: 0.78, green: 0.78, blue: 0.78), lineWidth: 1)
          )
          .offset(x: 0, y: 188)
        Text("Recover")
          .font(Font.custom("Roboto Mono", size: 16))
          .foregroundColor(Color(red: 0.85, green: 0.85, blue: 0.85))
          .offset(x: 0, y: 188.50)
        Text("Email@email.com")
          .font(Font.custom("Roboto Mono", size: 16))
          .foregroundColor(Color(red: 0.78, green: 0.78, blue: 0.78))
          .offset(x: -80.50, y: -143.50)
        Text("555-5555-5555")
          .font(Font.custom("Roboto Mono", size: 16))
          .foregroundColor(Color(red: 0.78, green: 0.78, blue: 0.78))
          .offset(x: -91.50, y: 111.50)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 184, height: 2)
          .background(Color(red: 0.78, green: 0.78, blue: 0.78))
          .offset(x: 112, y: 13)
        Rectangle()
          .foregroundColor(.clear)
          .frame(width: 184, height: 2)
          .background(Color(red: 0.78, green: 0.78, blue: 0.78))
          .offset(x: -110, y: 13)
        Text("Questions? Email at weneedabrandemail@forthis.com")
          .font(Font.custom("Roboto Mono", size: 11.50))
          .foregroundColor(Color(red: 0.85, green: 0.85, blue: 0.85))
          .offset(x: -0.50, y: 404)
      }
    }
    .frame(width: 430, height: 932)
    .background(.white);
  }
}

struct ForgetPasswordView_Previews: PreviewProvider {
  static var previews: some View {
    ForgetPasswordView()
  }
}
